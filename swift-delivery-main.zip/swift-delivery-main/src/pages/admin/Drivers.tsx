import { useState } from 'react';
import { mockDrivers } from '@/data/mockData';
import { DriverStatusBadge } from '@/components/dashboard/DriverStatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Plus, 
  Phone,
  Mail,
  Star,
  Bike,
  MapPin,
  MoreVertical
} from 'lucide-react';
import { Driver, DriverStatus } from '@/types/delivery';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function Drivers() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDrivers = mockDrivers.filter(driver =>
    driver.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    driver.phone.includes(searchQuery) ||
    driver.vehicleNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Drivers</h1>
          <p className="text-muted-foreground">Manage your delivery fleet</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Driver
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-sm text-muted-foreground">Total Drivers</p>
          <p className="text-2xl font-bold text-foreground mt-1">{mockDrivers.length}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-success animate-pulse-soft" />
            <p className="text-sm text-muted-foreground">Online</p>
          </div>
          <p className="text-2xl font-bold text-success mt-1">
            {mockDrivers.filter(d => d.status === 'ONLINE').length}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-warning" />
            <p className="text-sm text-muted-foreground">Busy</p>
          </div>
          <p className="text-2xl font-bold text-warning mt-1">
            {mockDrivers.filter(d => d.status === 'BUSY').length}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search drivers by name, phone, or vehicle..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Drivers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredDrivers.map((driver, index) => (
          <div 
            key={driver.id}
            className="bg-card rounded-xl border border-border p-5 hover:shadow-md transition-all duration-200 animate-fade-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="h-14 w-14 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center text-primary text-lg font-bold">
                    {driver.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <span className={`absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-2 border-card ${
                    driver.status === 'ONLINE' ? 'bg-success' : 
                    driver.status === 'BUSY' ? 'bg-warning' : 'bg-muted'
                  }`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{driver.name}</h3>
                  <p className="text-sm text-muted-foreground">{driver.id}</p>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>View Profile</DropdownMenuItem>
                  <DropdownMenuItem>Edit Details</DropdownMenuItem>
                  <DropdownMenuItem>View History</DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive">Deactivate</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <DriverStatusBadge status={driver.status} />
                <div className="flex items-center gap-1 text-warning">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="font-semibold">{driver.rating}</span>
                  <span className="text-muted-foreground text-sm">({driver.totalDeliveries})</span>
                </div>
              </div>

              <div className="pt-3 border-t border-border space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Bike className="h-4 w-4" />
                  <span>{driver.vehicleType} • {driver.vehicleNumber}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span>{driver.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span>{driver.email}</span>
                </div>
              </div>

              {driver.currentLocation && (
                <div className="pt-3 border-t border-border">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground">Last seen:</span>
                    <span className="text-foreground">
                      {driver.currentLocation.lat.toFixed(4)}, {driver.currentLocation.lng.toFixed(4)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-4 flex gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                <Phone className="h-4 w-4 mr-2" />
                Call
              </Button>
              <Button size="sm" className="flex-1">
                Assign Order
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
