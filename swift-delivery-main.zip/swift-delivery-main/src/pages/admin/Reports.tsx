import { BarChart3, TrendingUp, Calendar, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Reports() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reports</h1>
          <p className="text-muted-foreground">Analytics and business insights</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Placeholder */}
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4 shadow-glow">
          <BarChart3 className="h-8 w-8 text-primary-foreground" />
        </div>
        <h3 className="font-semibold text-foreground text-lg mb-2">Analytics Dashboard</h3>
        <p className="text-muted-foreground max-w-md mx-auto">
          Connect to a database to enable detailed analytics, revenue reports, delivery performance metrics, and driver efficiency tracking.
        </p>
        <Button className="mt-6">
          <TrendingUp className="h-4 w-4 mr-2" />
          Enable Analytics
        </Button>
      </div>
    </div>
  );
}
