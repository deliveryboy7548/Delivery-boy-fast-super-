import { Settings as SettingsIcon, Bell, Shield, MapPin, Webhook } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

export function Settings() {
  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground">Configure your delivery platform</p>
      </div>

      {/* Notifications */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg gradient-info flex items-center justify-center">
            <Bell className="h-5 w-5 text-info-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Notifications</h3>
            <p className="text-sm text-muted-foreground">Manage alert preferences</p>
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="new-orders">New order alerts</Label>
            <Switch id="new-orders" defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="driver-updates">Driver status updates</Label>
            <Switch id="driver-updates" defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="delivery-complete">Delivery completion alerts</Label>
            <Switch id="delivery-complete" />
          </div>
        </div>
      </div>

      {/* Maps Integration */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg gradient-success flex items-center justify-center">
            <MapPin className="h-5 w-5 text-success-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Maps Integration</h3>
            <p className="text-sm text-muted-foreground">Configure Mapbox for live tracking</p>
          </div>
        </div>
        <div className="space-y-3">
          <div>
            <Label htmlFor="mapbox-key">Mapbox Public Token</Label>
            <Input id="mapbox-key" placeholder="pk.eyJ1Ijoi..." className="mt-1.5" />
          </div>
          <Button variant="outline" size="sm">Save API Key</Button>
        </div>
      </div>

      {/* Webhooks */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg gradient-warning flex items-center justify-center">
            <Webhook className="h-5 w-5 text-warning-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Webhooks</h3>
            <p className="text-sm text-muted-foreground">Connect external services</p>
          </div>
        </div>
        <div className="space-y-3">
          <div>
            <Label htmlFor="webhook-url">Webhook URL</Label>
            <Input id="webhook-url" placeholder="https://your-service.com/webhook" className="mt-1.5" />
          </div>
          <Button variant="outline" size="sm">Add Webhook</Button>
        </div>
      </div>

      {/* Security */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg bg-destructive flex items-center justify-center">
            <Shield className="h-5 w-5 text-destructive-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Security</h3>
            <p className="text-sm text-muted-foreground">Manage access and authentication</p>
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="2fa">Two-factor authentication</Label>
            <Switch id="2fa" />
          </div>
          <Button variant="outline" size="sm">Change Password</Button>
        </div>
      </div>
    </div>
  );
}
