import { StatCard } from '@/components/dashboard/StatCard';
import { RecentOrdersTable } from '@/components/dashboard/RecentOrdersTable';
import { ActiveDriversList } from '@/components/dashboard/ActiveDriversList';
import { LiveMapPlaceholder } from '@/components/dashboard/LiveMapPlaceholder';
import { mockOrders, mockDrivers, mockStats } from '@/data/mockData';
import { 
  Package, 
  Truck, 
  CheckCircle2, 
  IndianRupee,
  Clock,
  TrendingUp
} from 'lucide-react';

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Today</p>
          <p className="text-lg font-semibold text-foreground">
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' })}
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          title="Total Orders"
          value={mockStats.totalOrders.toLocaleString()}
          change="+12% from last week"
          changeType="positive"
          icon={Package}
        />
        <StatCard
          title="Active Orders"
          value={mockStats.activeOrders}
          icon={TrendingUp}
          iconBg="gradient-warning"
        />
        <StatCard
          title="Completed Today"
          value={mockStats.completedToday}
          change="+8 from yesterday"
          changeType="positive"
          icon={CheckCircle2}
          iconBg="gradient-success"
        />
        <StatCard
          title="Online Drivers"
          value={mockStats.onlineDrivers}
          icon={Truck}
          iconBg="gradient-info"
        />
        <StatCard
          title="Today's Revenue"
          value={`₹${mockStats.revenue.toLocaleString()}`}
          change="+15% from yesterday"
          changeType="positive"
          icon={IndianRupee}
        />
        <StatCard
          title="Avg. Delivery Time"
          value={`${mockStats.avgDeliveryTime} min`}
          change="-3 min improvement"
          changeType="positive"
          icon={Clock}
          iconBg="gradient-success"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Orders Table - spans 2 columns */}
        <div className="lg:col-span-2">
          <RecentOrdersTable orders={mockOrders} />
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <LiveMapPlaceholder />
          <ActiveDriversList drivers={mockDrivers} />
        </div>
      </div>
    </div>
  );
}
