import { Users, Search, MapPin, Phone, Mail, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const mockCustomers = [
  { id: 'CUST-001', name: 'Rajesh Kumar', phone: '+91 98765 43210', email: 'rajesh@email.com', orders: 12, totalSpent: 4560 },
  { id: 'CUST-002', name: 'Priya Sharma', phone: '+91 87654 32109', email: 'priya@email.com', orders: 8, totalSpent: 2890 },
  { id: 'CUST-003', name: 'Anand Verma', phone: '+91 76543 21098', email: 'anand@email.com', orders: 23, totalSpent: 8920 },
  { id: 'CUST-004', name: 'Lakshmi Devi', phone: '+91 65432 10987', email: 'lakshmi@email.com', orders: 5, totalSpent: 1450 },
  { id: 'CUST-005', name: 'Vikram Singh', phone: '+91 54321 09876', email: 'vikram@email.com', orders: 15, totalSpent: 5670 },
];

export function Customers() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Customers</h1>
          <p className="text-muted-foreground">Manage your customer base</p>
        </div>
        <Button>
          <Users className="h-4 w-4 mr-2" />
          Add Customer
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-sm text-muted-foreground">Total Customers</p>
          <p className="text-2xl font-bold text-foreground mt-1">{mockCustomers.length}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-sm text-muted-foreground">Total Orders</p>
          <p className="text-2xl font-bold text-foreground mt-1">
            {mockCustomers.reduce((acc, c) => acc + c.orders, 0)}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-sm text-muted-foreground">Total Revenue</p>
          <p className="text-2xl font-bold text-foreground mt-1">
            ₹{mockCustomers.reduce((acc, c) => acc + c.totalSpent, 0).toLocaleString()}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search customers..." className="pl-10" />
      </div>

      {/* Customers Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-muted/30">
              <th className="px-6 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Customer</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Contact</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Orders</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-muted-foreground uppercase">Total Spent</th>
              <th className="px-6 py-3 text-right text-xs font-semibold text-muted-foreground uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {mockCustomers.map((customer, index) => (
              <tr 
                key={customer.id}
                className="hover:bg-muted/20 transition-colors animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      {customer.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{customer.name}</p>
                      <p className="text-xs text-muted-foreground">{customer.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" />
                      {customer.phone}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Mail className="h-3.5 w-3.5" />
                      {customer.email}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{customer.orders}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="font-semibold text-foreground">₹{customer.totalSpent.toLocaleString()}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <Button variant="ghost" size="sm">View Details</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
