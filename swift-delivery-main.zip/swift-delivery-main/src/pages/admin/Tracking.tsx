import { MapPin, Navigation, Package, Clock, Phone } from 'lucide-react';
import { mockOrders, mockDrivers } from '@/data/mockData';
import { OrderStatusBadge } from '@/components/dashboard/OrderStatusBadge';
import { Button } from '@/components/ui/button';

export function Tracking() {
  const activeOrders = mockOrders.filter(o => o.status === 'ONROUTE' || o.status === 'ASSIGNED');
  const onlineDrivers = mockDrivers.filter(d => d.status !== 'OFFLINE');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Live Tracking</h1>
          <p className="text-muted-foreground">Monitor active deliveries in real-time</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="h-2 w-2 rounded-full bg-success animate-pulse-soft" />
          <span className="text-muted-foreground">{onlineDrivers.length} drivers online</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="lg:col-span-2">
          <div className="bg-card rounded-xl border border-border overflow-hidden h-[600px] relative">
            {/* Map Placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-muted/30 via-muted/50 to-muted/30">
              {/* Decorative grid lines */}
              <div className="absolute inset-0" style={{
                backgroundImage: `
                  linear-gradient(rgba(0,0,0,0.03) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(0,0,0,0.03) 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px'
              }} />
              
              {/* Mock driver markers */}
              {onlineDrivers.map((driver, i) => (
                <div 
                  key={driver.id}
                  className="absolute animate-bounce-gentle"
                  style={{ 
                    top: `${20 + (i * 15)}%`, 
                    left: `${15 + (i * 20)}%`,
                    animationDelay: `${i * 0.3}s`
                  }}
                >
                  <div className="relative group cursor-pointer">
                    <div className={`h-10 w-10 rounded-full ${
                      driver.status === 'BUSY' ? 'gradient-warning' : 'gradient-success'
                    } flex items-center justify-center shadow-lg transform transition-transform group-hover:scale-110`}>
                      <Navigation className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div className="absolute left-1/2 -translate-x-1/2 mt-2 bg-card px-3 py-1.5 rounded-lg shadow-lg border border-border opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      <p className="text-sm font-medium">{driver.name}</p>
                      <p className="text-xs text-muted-foreground">{driver.vehicleNumber}</p>
                    </div>
                  </div>
                </div>
              ))}

              {/* Destination markers */}
              {activeOrders.slice(0, 3).map((order, i) => (
                <div 
                  key={order.id}
                  className="absolute"
                  style={{ 
                    bottom: `${20 + (i * 20)}%`, 
                    right: `${20 + (i * 15)}%`
                  }}
                >
                  <div className="relative group cursor-pointer">
                    <div className="h-8 w-8 rounded-full bg-destructive flex items-center justify-center shadow-lg">
                      <MapPin className="h-4 w-4 text-destructive-foreground" />
                    </div>
                    <div className="absolute right-0 mt-2 bg-card px-3 py-1.5 rounded-lg shadow-lg border border-border opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      <p className="text-sm font-medium">{order.id}</p>
                      <p className="text-xs text-muted-foreground line-clamp-1">{order.dropoff.address}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Center overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center bg-card/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-border">
                <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4 shadow-glow">
                  <MapPin className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Connect Mapbox</h3>
                <p className="text-sm text-muted-foreground mb-4 max-w-xs">
                  Add your Mapbox API key to enable real-time driver tracking and route visualization
                </p>
                <Button>Configure Maps</Button>
              </div>
            </div>

            {/* Map controls */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <Button variant="secondary" size="icon" className="shadow-md">
                <span className="text-lg">+</span>
              </Button>
              <Button variant="secondary" size="icon" className="shadow-md">
                <span className="text-lg">−</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Active Deliveries List */}
        <div className="space-y-4">
          <h2 className="font-semibold text-foreground">Active Deliveries ({activeOrders.length})</h2>
          
          <div className="space-y-3 max-h-[560px] overflow-y-auto">
            {activeOrders.map((order, index) => (
              <div 
                key={order.id}
                className="bg-card rounded-xl border border-border p-4 hover:shadow-md transition-all animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-foreground">{order.id}</span>
                      <OrderStatusBadge status={order.status} />
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{order.customerName}</p>
                  </div>
                  <span className="text-lg font-bold text-foreground">₹{order.price}</span>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-success/20 flex items-center justify-center shrink-0 mt-0.5">
                      <Package className="h-3 w-3 text-success" />
                    </div>
                    <p className="text-muted-foreground line-clamp-1">{order.pickup.address}</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-destructive/20 flex items-center justify-center shrink-0 mt-0.5">
                      <MapPin className="h-3 w-3 text-destructive" />
                    </div>
                    <p className="text-muted-foreground line-clamp-1">{order.dropoff.address}</p>
                  </div>
                </div>

                {order.assignedDriverName && (
                  <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-info/10 flex items-center justify-center text-info text-xs font-semibold">
                        {order.assignedDriverName.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="text-sm font-medium">{order.assignedDriverName}</span>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Phone className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {order.estimatedDelivery && (
                  <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>ETA: {new Date(order.estimatedDelivery).toLocaleTimeString('en-IN', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}</span>
                  </div>
                )}
              </div>
            ))}

            {activeOrders.length === 0 && (
              <div className="text-center py-8">
                <Package className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground">No active deliveries</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
