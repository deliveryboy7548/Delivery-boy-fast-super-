export type OrderStatus = 'PENDING' | 'ASSIGNED' | 'ONROUTE' | 'DELIVERED' | 'CANCELLED';

export type DriverStatus = 'ONLINE' | 'OFFLINE' | 'BUSY';

export interface Location {
  lat: number;
  lng: number;
  address: string;
}

export interface OrderItem {
  name: string;
  qty: number;
  price: number;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  items: OrderItem[];
  pickup: Location;
  dropoff: Location;
  assignedDriverId?: string;
  assignedDriverName?: string;
  status: OrderStatus;
  price: number;
  taxes: number;
  createdAt: Date;
  updatedAt: Date;
  estimatedDelivery?: Date;
  proofImageUrl?: string;
  otp?: string;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  email: string;
  vehicleType: string;
  vehicleNumber: string;
  status: DriverStatus;
  currentLocation?: {
    lat: number;
    lng: number;
    timestamp: Date;
  };
  rating: number;
  totalDeliveries: number;
  avatar?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  addresses: Location[];
}

export interface DashboardStats {
  totalOrders: number;
  activeOrders: number;
  completedToday: number;
  onlineDrivers: number;
  revenue: number;
  avgDeliveryTime: number;
}
