import { Driver } from '@/types/delivery';
import { DriverStatusBadge } from './DriverStatusBadge';
import { Star, Bike, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ActiveDriversListProps {
  drivers: Driver[];
  onCallDriver?: (driverId: string) => void;
  onViewDriver?: (driverId: string) => void;
}

export function ActiveDriversList({ drivers, onCallDriver, onViewDriver }: ActiveDriversListProps) {
  const onlineDrivers = drivers.filter(d => d.status !== 'OFFLINE');

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="px-6 py-4 border-b border-border flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Active Drivers</h3>
        <span className="text-sm text-muted-foreground">{onlineDrivers.length} online</span>
      </div>
      <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
        {onlineDrivers.map((driver, index) => (
          <div 
            key={driver.id} 
            className="px-6 py-4 hover:bg-muted/20 transition-colors animate-fade-in"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-foreground font-semibold">
                    {driver.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <span className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card ${
                    driver.status === 'ONLINE' ? 'bg-success' : 'bg-warning'
                  }`} />
                </div>
                <div>
                  <p className="font-medium text-foreground">{driver.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Bike className="h-3 w-3" />
                      {driver.vehicleNumber}
                    </div>
                    <span className="text-muted-foreground/30">•</span>
                    <div className="flex items-center gap-1 text-xs text-warning">
                      <Star className="h-3 w-3 fill-current" />
                      {driver.rating}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <DriverStatusBadge status={driver.status} />
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onCallDriver?.(driver.id)}
                >
                  <Phone className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
