import { MapPin, Navigation } from 'lucide-react';

export function LiveMapPlaceholder() {
  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="px-6 py-4 border-b border-border flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Live Tracking</h3>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="h-2 w-2 rounded-full bg-success animate-pulse-soft" />
          Live
        </div>
      </div>
      <div className="relative h-[300px] bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center">
        {/* Decorative map elements */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-32 h-px bg-muted-foreground" />
          <div className="absolute top-10 left-10 w-px h-40 bg-muted-foreground" />
          <div className="absolute top-20 left-20 w-48 h-px bg-muted-foreground" />
          <div className="absolute bottom-20 right-20 w-40 h-px bg-muted-foreground" />
          <div className="absolute bottom-10 right-10 w-px h-32 bg-muted-foreground" />
          <div className="absolute top-1/3 left-1/4 w-24 h-px bg-muted-foreground rotate-45" />
          <div className="absolute bottom-1/3 right-1/4 w-32 h-px bg-muted-foreground -rotate-45" />
        </div>
        
        {/* Mock driver pins */}
        <div className="absolute top-16 left-1/4 animate-bounce-gentle">
          <div className="relative">
            <div className="h-8 w-8 rounded-full gradient-primary flex items-center justify-center shadow-lg">
              <Navigation className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-6 border-l-transparent border-r-transparent border-t-primary" />
          </div>
        </div>
        
        <div className="absolute bottom-24 right-1/3 animate-bounce-gentle" style={{ animationDelay: '0.5s' }}>
          <div className="relative">
            <div className="h-8 w-8 rounded-full gradient-info flex items-center justify-center shadow-lg">
              <Navigation className="h-4 w-4 text-info-foreground" />
            </div>
            <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-6 border-l-transparent border-r-transparent border-t-info" />
          </div>
        </div>

        <div className="absolute top-1/2 right-1/4">
          <div className="h-6 w-6 rounded-full bg-destructive/80 flex items-center justify-center shadow-md">
            <MapPin className="h-3 w-3 text-destructive-foreground" />
          </div>
        </div>

        {/* Center message */}
        <div className="text-center z-10">
          <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-3 shadow-glow">
            <MapPin className="h-8 w-8 text-primary-foreground" />
          </div>
          <p className="text-sm font-medium text-muted-foreground">
            Connect Mapbox to enable live tracking
          </p>
        </div>
      </div>
    </div>
  );
}
