import { DriverStatus } from '@/types/delivery';
import { cn } from '@/lib/utils';

interface DriverStatusBadgeProps {
  status: DriverStatus;
}

const statusConfig: Record<DriverStatus, { label: string; className: string }> = {
  ONLINE: { label: 'Online', className: 'bg-success/15 text-success' },
  OFFLINE: { label: 'Offline', className: 'bg-muted text-muted-foreground' },
  BUSY: { label: 'Busy', className: 'bg-warning/15 text-warning' },
};

export function DriverStatusBadge({ status }: DriverStatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <span className={cn('status-badge', config.className)}>
      <span className={cn(
        'mr-1.5 h-1.5 w-1.5 rounded-full',
        status === 'ONLINE' && 'bg-success animate-pulse-soft',
        status === 'OFFLINE' && 'bg-muted-foreground',
        status === 'BUSY' && 'bg-warning'
      )} />
      {config.label}
    </span>
  );
}
